# Country coastline outlines

`coastlines110.json` and `coastlines50.json` are compact longitude/latitude
LineString arrays from Natural Earth coastline data (110m and 50m), rounded
to four decimal places without removing islands or simplifying geometry.

Source: https://github.com/nvkelso/natural-earth-vector/tree/master/geojson

Source files: `ne_110m_coastline.geojson`, `ne_50m_coastline.geojson`.
Retrieved: 2026-10-12. License: public domain.

The geography provider combines these with the existing same-scale shared
land borders so the Countries toggle includes the full coastal outline.